# load packages
library(shiny)
library(tidyverse)

#load data
vgsales = read_csv("data/vgsales.csv")

ui = navbarPage(
  title= "VGSales",
  tabPanel(title = "Input/Viz",
           titlePanel(title = "Video Game Region Sales"),
           sidebarLayout(
             sidebarPanel(
               selectInput(inputId = "pub",
                           label = "Publisher:",
                           choices = sort(unique(vgsales$Publisher)),
                           selected = "Nintendo"),
               selectInput(inputId = "plat",
                           label = "Platform:",
                           choices = sort(unique(vgsales$Platform)),),
               selectInput(inputId = "gen",
                           label = "Genre:",
                           choices = sort(unique(vgsales$Genre)),
                           selected = "Platform"),
               checkboxInput(inputId = "filt",
                             label = "Filter Table Using Specified Parameters",
                             value = FALSE)
              ),
             mainPanel(plotOutput("plot"))
           )
          ),
  tabPanel(title = "Table", dataTableOutput("table")),
  tabPanel(title = "About", includeMarkdown("about.Rmd"))
  )

server <- function(input, output) {

    # reactive elements
    vgsales_pub = reactive({
      vgsales %>%
        filter(Publisher == input$pub)
    })
    observeEvent(eventExpr = input$pub,
                 handlerExpr = {
                   updateSelectInput(inputId = "plat",
                                     choices = sort(unique(vgsales_pub()$Platform)))
                   updateSelectInput(inputId = "gen",
                                     choices = sort(unique(vgsales_pub_plat()$Genre)))
                 }
    )

    vgsales_pub_plat = reactive({
      vgsales_pub() %>%
        filter(Platform == input$plat)
    })
    observeEvent(eventExpr = input$plat,
                 handlerExpr = {
                   updateSelectInput(inputId = "gen",
                                     choices = sort(unique(vgsales_pub_plat()$Genre)))
                 }
    )

    # render plot
    output$plot <- renderPlot({

      vgsales %>%
        select(Platform, Year, Genre, Publisher, NA_Sales, EU_Sales, JP_Sales,Other_Sales) %>%
        filter(Publisher == input$pub) %>%
        filter(Genre == input$gen) %>%
        filter(Platform == input$plat) %>%
        # mutate(Year = as.integer(Year)) %>%
        group_by(Year) %>%
        summarise(`North America` = sum(NA_Sales),
                  Europe = sum(EU_Sales),
                  Japan = sum(JP_Sales),
                  Other = sum(Other_Sales)) %>% # Global_Sales = sum(Global_Sales)
        pivot_longer(cols = c(`North America`, Europe, Japan, Other),
                     names_to = "Region",
                     values_to = "Sales")  %>%
        ggplot() +
        aes(fill = Region, x = Year, y = Sales) %>%
        geom_bar(position = "stack", stat = "identity") +
        labs(x = "Years", y = "Sales (Millions)")

    })

    output$table = renderDataTable({

      tab = vgsales

      if (input$filt){
        tab = tab %>%
          filter(Publisher == input$pub) %>%
          filter(Genre == input$gen) %>%
          filter(Platform == input$plat)
      }

      tab

    })
}

shinyApp(ui = ui, server = server)

