library(tidyverse)
library(readr)

vgsales = read_csv("data/vgsales.csv")

vgsales = vgsales %>%
  arrange(Rank)

write_csv(x= vgsales, file = "data/vgsales.csv")
